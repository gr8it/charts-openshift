# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.2] - 2026-10-01

### Changed 

- Upgrade operator version to 4.11.4

## [1.0.1] - 2026-01-20

### Changed 

- Upgrade operator version to 4.8.7


## [1.0.0] - 2025-12-13

_Initial release._
