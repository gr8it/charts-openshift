# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.4.1] - 2026-11-23

### Changed

- Bump to version quay-operator.v3.18.3

## [1.4.0] - 2026-08-14

### Changed

- Updated quay operator to v3.18.0
