# GitOps bootstrap

This helm chart bootstraps APC GitOps using ACM policies to all managed clusters (global clusterset) using ACM policy framework:

- operatorpolicy to install ArgoCD opererator on managed clusters
- configurationpolicy to copy Gitops repo credentials secret from hub to managed clusters
- configurationpolicy to create Gitops repo secret on managed clusters
- configurationpolicy to create network policies for argocd to communicate correctly
- configurationpolicy to create App of Apps ArgoCD application on managed clusters with disabled sync to allow override in case of a problem

## Argo CD health checks

The bootstrapped Argo CD instance includes custom health checks for `Application`, HyperShift `HostedCluster`, and `NodePool` resources, configured through `spec.resourceHealthChecks`. The HostedCluster check reports Healthy only after the desired version in status matches the latest completed history entry and its `Available` condition is true for its current generation. The NodePool check reports Progressing while its configuration, version, or platform machine template is updating, even when `Ready` is still true; it reports Healthy only when `Ready` is true for the current generation. NodePools use a later sync wave so they wait for the HostedCluster upgrade to complete.

## Manual steps

When auto sync is not enabled for the argocd-app-of-apps application (default), the synchronization must be enabled temporarily by manually running the following commands **in the GitOps namespace** (the value of `.Values.namespace`, default `apc-gitops`):

```bash
# temporarily enable auto sync
kubectl patch application argocd-app-of-apps -n <gitops-namespace> --type merge -p '{"spec":{"syncPolicy":{"automated":{"selfHeal": true}}}}'
# disable auto sync, after the sync started (can be checked in the application CR status)
kubectl patch application argocd-app-of-apps -n <gitops-namespace> --type merge -p '{"spec":{"syncPolicy":{"automated": null}}}'
```

## OperatorPolicies not working

Because of a bug in ACM <https://access.redhat.com/support/cases/#/case/04386303/discussion> / <https://issues.redhat.com/browse/ACM-30555>, the operator policy controller is not enabled in the ACM configuration controller addon until cluster installation is finished (that is, until the ingress controller cluster operator reports as healthy). The controller is missing the `--enable-operator-policy=true` flag. However, we need OperatorPolicy to finish the installation (installing MetalLB and configuring it), resulting in a chicken-and-egg problem.

The workaround until a permanent solution is available is to annotate the particular `managedclusteraddon` on the hub cluster:

```bash
kubectl annotate managedclusteraddon config-policy-controller -n <hosted-cluster-namespace> operator-policy-disabled=false
```
