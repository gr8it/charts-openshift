{{/*
Expand the name of the chart.
*/}}
{{- define "cluster-config-standalone.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "cluster-config-standalone.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cluster-config-standalone.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cluster-config-standalone.labels" -}}
helm.sh/chart: {{ include "cluster-config-standalone.chart" . }}
{{ include "cluster-config-standalone.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cluster-config-standalone.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cluster-config-standalone.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "cluster-config-standalone.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "cluster-config-standalone.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Defines image proxy URL without protocol
*/}}
{{- define "cluster-config-standalone.imageProxyUrl" -}}
{{- if eq (int .Values.imageProxy.port) 443 }}
{{- .Values.imageProxy.host }}
{{- else }}
{{- .Values.imageProxy.host }}:{{ .Values.imageProxy.port }}
{{- end }}
{{- end }}

{{/*
Defines dedicatedEtcdStorageConfig
*/}}
{{- define "cluster-config-standalone.dedicatedEtcdStorageConfig" -}}
#!/bin/bash
set -uo pipefail

devices="{{ join " \\\n         " .Values.dedicatedEtcdStorageDevices }}"

for device in $devices; do
  /usr/bin/test -b "$device" || continue
  /usr/sbin/blkid "$device" &> /dev/null
  if [ $? == 2 ]; then
    echo "Secondary block device found: $device"
    echo "Creating filesystem for etcd mount"
    /usr/sbin/mkfs.xfs -L var-lib-etcd -f "$device" &> /dev/null
    /usr/sbin/udevadm settle
    /usr/bin/touch /etc/var-lib-etcd-mount
    exit 0
  fi
done
echo "Couldn't find secondary block device!" >&2
exit 77
{{- end }}
