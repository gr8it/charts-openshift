# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-06-23

_Initial release._

Migrates the Cluster Logging Operator from hand-applied static manifests
(`ocp-<cluster>/observability/logging/06-logging-operator.yaml`) to a GitOps-managed
helm release using ACM `OperatorPolicy`. Reproduces the existing install with manual
install-plan approval (`upgradeApproval: None`) and a baseline `startingCSV` of
`cluster-logging.v6.1.4`, with per-cluster overrides required for `hub01`, `huba`, and
`spokea1`. The chart baseline carries `stable-6.1`; QA clusters override to `stable-6.2`.
The Helm chart itself is named `cluster-logging-operator`; the managed Subscription
remains `cluster-logging`. The operator is installed into its own dedicated namespace
`openshift-cluster-logging-operator` with a dedicated `OperatorGroup`.
