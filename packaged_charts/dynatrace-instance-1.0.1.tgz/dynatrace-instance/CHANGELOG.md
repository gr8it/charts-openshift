# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-09-29

### Fixed

- Cluster Name in Dynatrace

## [1.0.0] - 2026-09-17

### Added

- Initial release.
