# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.1] - 2026-11-12

### Fixed

- Keep LDAP connection settings outside the attribute mappings in the deprecated integration helpers

## [2.0.0] - 2026-10-15

### Changed

- Change `sshAuthorizedKeys` from a string to a list and add bundle helpers
- Add the `identityProviders` helper and deprecate `adIntegration` and `ldapIntegration`

## [1.10.0] - 2026-08-03

### Added

- `apc-global-overrides.imageProxyHost` and `apc-global-overrides.require-imageProxyHost` helpers
- `apc-global-overrides.imageProxySources` helper
- `apc-global-overrides.adIntegration` helper
- `apc-global-overrides.ldapIntegration` helper
- `apc-global-overrides.ntpServers`, `apc-global-overrides.require-ntpServers` and `apc-global-overrides.chronyConfig` which uses the ntpServers helper functions
- `apc-global-overrides.sshAuthorizedKeys` and `apc-global-overrides.require-sshAuthorizedKeys` helpers for SSH authorized keys

### Changed

- use `apc-global-overrides.merge-services` for all service extraction

## [1.9.0] - 2026-08-26

_([SPEXAPC-7744](https://aspecta.atlassian.net/browse/SPEXAPC-7744))_

### Added

- apc-global-overrides.customerName / apc-global-overrides.require-customerName helpers

## [1.8.0] - 2026-03-02

_([SPEXAPC-13223](https://aspecta.atlassian.net/browse/SPEXAPC-13223))_

### Added

- `apc-global-overrides.clusterRootDomain` helper
- `apc-global-overrides.clusterRootDomain` helper

## [1.7.0] - 2026-02-13

_([SPEXAPC-7592](https://example.atlassian.net/browse/SPEXAPC-7592))_

### Added

- `apc-global-overrides.crossplaneKubeKeycloakProviderConfigName` helper
- `apc-global-overrides.keycloakUrl` helper
- `apc-global-overrides.keycloakRealm` helper
- `apc-global-overrides.crossplaneKubeKeycloakProviderConfigName` helper
- `apc-global-overrides.keycloakUrl` helper
- `apc-global-overrides.keycloakRealm` helper

## [1.6.0] - 2026-02-10

_([SPEXAPC-8916](https://aspecta.atlassian.net/browse/SPEXAPC-8916))_

### Added

- `apc-global-overrides.metallbL2Interface` helper
- `apc-global-overrides.metallbL2Interface` helper

## [1.5.0] - 2025-10-29

_([JIRA-6770](https://example.atlassian.net/browse/JIRA-6770))_

### Added

- `apc-global-overrides.metallbNamespace` helper
- `apc-global-overrides.metallbNamespace` helper
- docs: currently supported configuration
- docs: service specific helpers

### Changed

- apc-global-overrides.vaultKVmountPlatform = added default - apc-platform
- docs: added defaults / descriptions to helper functions

## [1.4.0] - 2025-08-23

_Initial release._
