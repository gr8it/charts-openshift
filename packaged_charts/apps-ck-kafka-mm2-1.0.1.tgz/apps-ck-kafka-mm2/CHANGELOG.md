# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-07-27

### Added

- adding detailed information about replicaiton users settings
- setting 2 replicas in default values

## [1.0.0] - 2026-06-15

_Initial release._
