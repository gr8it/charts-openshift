# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.5] - 2026-11-05

- Set an own-namespace OperatorGroup for fresh OpenShift 4.19 installations. Check existing OperatorGroups with different names before rollout.

## [1.0.4] - 2026-11-02

- `kubevirt-hyperconverged-operator.v4.19.33` → `kubevirt-hyperconverged-operator.v4.19.37` (current `stable` channel head); added to `versions`

## [1.0.3] - 2026-10-29

- `kubevirt-hyperconverged-operator.v4.18.45` → `kubevirt-hyperconverged-operator.v4.19.33`, added to `versions`; matches huba and spokea1

## [1.0.2] - 2026-08-28

- `kubevirt-hyperconverged-operator.v4.18.0` → `kubevirt-hyperconverged-operator.v4.18.45`
- `versions` expanded to the full stable-channel hop chain (`v4.17.5` → `v4.17.7` → `v4.18.0` … `v4.18.45`) so ACM auto-approves every step instead of stalling on unlisted intermediate CSVs

## [1.0.1] - 2026-08-18

- `kubevirt-hyperconverged-operator.v4.17.5` → `kubevirt-hyperconverged-operator.v4.18.0`

## [1.0.0] - 2026-07-13

_Initial release._
