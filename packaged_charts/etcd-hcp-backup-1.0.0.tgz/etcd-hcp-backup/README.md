# Hosted Control Plane ETCD Backup

This Helm Chart will deploy a Hosted Control Plane ETCD backup job.  
The Job will create an etcd snapshot, optionally compress it (controlled by `compressSnapshot`), and upload it to an S3 endpoint.

## Chart Variables

> [!NOTE]  
> Each variable without a default value is mandatory.  
> All chart resources are deployed into the Helm release namespace (set via `helm install -n <namespace>`). The ObjectBucketClaim must exist in that namespace beforehand, or the chart can create one by setting `objectBucketClaim.create: true`.

|Variable                         | Type | Default                         |  Notes |
|:---                             |:---  |:---                             |:---    |
| cluster.name                     | str  |                                 | Name of the Hosted Cluster. Defaults to `global.apc.cluster.name` when not set. |
| clusterNamespace                | str  | `{cluster.name}-{cluster.name}`   | Overrides the default Hosted Cluster namespace |
| backupSchedule                  | str  | `"0 * * * *"`                   | Cron notation for ETCD backup schedule |
| retentionDays                   | int  | `3`                             | Specifies the number of days to retain old backups during the cleanup phase  |
| etcdStatefulSetName             | str  | `etcd`                          | An optional parameter that overrides the default etcd StatefulSet name in  the Hosted Cluster namespace |
| compressSnapshot                | bool | `false`                         | Controls whether to use gzip to compress the snapshot before uploading to S3 |
| objectBucketClaim.name          | str  | `etcd-hcp-{cluster.name}-backup` | This parameter is mandatory when using a pre-existing ObjectBucketClaim. Overrides the default ObjectBucketClaim name if `{objectBucketClaim.create}` is `true` |
| objectBucketClaim.storageClass  | str  | `ocs-storagecluster-ceph-rgw`   | An optional parameter that defines a storageClass for the ObjectBucketClaim. Only used when `{objectBucketClaim.create}` is `true` |
| image.awscli                    | str  | `amazon/aws-cli:2.24.27`                       | Container image with `aws` cli tool |
| image.ocpcli                    | str  | `registry.redhat.io/openshift4/ose-cli:v4.15`  | Container image with `kubectl` and `oc` cli tool |
| image.etcd                      | str  | `registry.redhat.io/openshift4/ose-etcd:v4.12` | Container image with `etcdctl` and `etcdutl` cli tool |

## Example Deployment

```yaml
# my-values.yaml
cluster:
  name: ocpdemo-spoke2
backupSchedule: "20 */3 * * *"
retentionDays: 10
objectBucketClaim:
  name: etcd-hcp-ocpdemo-spoke2-backup
```

```sh
$ helm -n apc-backup install -f my-values.yaml etcd-hcp-ocpdemo-spoke2-backup .
NAME: etcd-hcp-ocpdemo-spoke2-backup
LAST DEPLOYED: Fri Mar 28 10:08:09 2025
NAMESPACE: apc-backup
STATUS: deployed
REVISION: 1
TEST SUITE: None
```
