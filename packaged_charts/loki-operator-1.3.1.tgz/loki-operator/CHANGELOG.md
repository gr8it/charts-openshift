# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.3.1] - 2026-11-23

### Changed

- Bump to version loki-operator.v6.4.7

## [1.3.0] - 2026-09-07

### Changed

- Upgrade the Loki Operator to `stable-6.4` / `loki-operator.v6.4.6`.

## [1.2.1] - 2026-08-11

Fix the Loki Operator metrics ServiceMonitor policy to enforce the full HTTPS scrape endpoint, bearer-token authentication, service CA, labels, and the correct TLS server name for the operator namespace.

## [1.2.0] - 2026-08-10

Bump to `stable-6.2` / `loki-operator.v6.2.12`.

## [1.1.1] - 2026-07-07

Fix Loki Operator metrics policy ServiceMonitor matching after namespace migration.

## [1.1.0] - 2026-07-07

Fix Loki Operator metrics ServiceMonitor TLS server name and metrics-reader RBAC after namespace migration.

## [1.0.0] - 2026-06-23

_Initial release._
