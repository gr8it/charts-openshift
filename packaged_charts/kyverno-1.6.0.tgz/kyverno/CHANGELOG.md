# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.6.0] - 2026-09-22

### Added

- Added Kyverno Grafana dashboard and PrometheusRule alerts for UpdateRequest backlog

### Changed

- `backgroundScanInterval` 5m → 1h

_([SPEXAPC-2578](https://aspecta.atlassian.net/browse/SPEXAPC-2578))_

## [1.5.1] - 2026-04-21

### Changed

- Updated prometheus rule so it doesn't create false alarms.

## [1.5.0] - 2026-02-12

### Added

- Added `KyvernoBackgroundControllerDown` alert — detects background controller outage (responsible for generating resources for existing namespaces)
- Added `KyvernoAdmissionControllerDown` alert — detects admission controller outage (responsible for generating resources for new namespaces)

### Fixed

- Fixed KyvernoPolicyResultsFail alert rate window from `[5d]` to `[15m]` — 5-day window was keeping alert active long after a single historical failure

## [1.4.1] - 2026-02-09

### Changed

- Updated memory limit for `apc-kyverno-controller` in `values.yaml` (key `resources.limits.memory`)

## [1.4.0] - 2026-02-26

### Added

- Added Prometheus rules for Kyverno policy failures and errors

## [1.3.1] - 2026-01-14

- Patch version update of HC to 3.5.2
- Increased CPU and Memory limits

_([SPEXAPC-11169](https://aspecta.atlassian.net/browse/SPEXAPC-11169))_

## [1.3.0] - 2025-11-10

### Changed

- Increased memory limit

_([SPEXAPC-8236](https://aspecta.atlassian.net/browse/SPEXAPC-8236))_
