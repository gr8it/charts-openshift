# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.11.1] - 2026-09-10

### Fixed

- ArgoCD PrometheusRule object-templates use `complianceType: mustonlyhave` instead of `musthave` - `musthave` never prunes stale array entries, so every content change to `ArgoCDAppSyncUnknownAlert`/`ArgocdServiceUnhealthy` left the old version stacked alongside the new one on managed clusters, firing both together in the same notification

## [2.11.0] - 2026-09-10

### Changed

- Reduce ArgoCD sync/health alert labels to object-identifying ones only (drop scrape metadata)

## [2.10.0] - 2026-09-02

### Changed

- Curate ArgoCD sync/health alert descriptions, add `argocdAlertSeverity` value

## [2.9.4] - 2026-08-27

## [2.9.3] - 2026-04-09

### Changed

- Increase dex memory limits from 256Mi to 512Mi and requests from 128Mi to 256Mi

## [2.9.2] - 2026-03-02

### Fixed

- add more netpols for the communication to work

### Added

- add manual steps required to finish bootstrap

## [2.9.1] - 2026-03-02

### Fixed

- fix egress netpol for kubeapi when HCP is used

## [2.9.0] - 2026-02-10

### Added

- add egress netpol for kubeapi if egress proxy netpol is created
- add ingress netpol for openshift ingress

## [2.8.2] - 2026-02-11

### Changed

- Increase memory limits for ArgoCD component controller to improve performance

## [2.8.1] - 2026-01-19

### Changed

- Enabled v1.Endpoint and v1.EndpointSlice in ArgoCD

## [1.0.0] - 2025-06-16

_Initial release._
