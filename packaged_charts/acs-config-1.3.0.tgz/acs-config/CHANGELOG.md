# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Common Changelog](https://common-changelog.org/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.3.0] - 2026-10-21

### Added

- Optional ObjectBucketClaim (`objectBucketClaim.create`, disabled by default).

## [1.2.0] - 2026-06-23

### Changed

- Increased Central scanner DB memory limit to 12Gi.

## [1.1.0] - 2026-04-29

## Added

- acs policy charts/acs-config/policies/containers-critical-fixable-cves.json

## [1.0.1] - 2026-02-26

### Changed
- scannerV4 memory bump

## [1.0.0] - 2025-12-13

_Initial release._
