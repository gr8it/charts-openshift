# Changelog

## [1.2.0] - 2026-10-20

### Added

- Optional `thanos-tls-ca` Secret (`thanosTlsCa.caBundle`) on hub clusters

## [1.1.1] - 2026-09-23

### Removed

- Gitlab, CICD availability dashboards, report and panels

## [1.1.0] - 2026-08-27

_([SPEXAPC-3367](https://aspecta.atlassian.net/browse/SPEXAPC-3367))_


### Added

- MongoDB instance report metrics added to the UWL allowlist
- MongoDB instances per namespace panel to the "MongoDB service availability" dashboard


## [1.0.0] - 2026-04-25

Initial version.
